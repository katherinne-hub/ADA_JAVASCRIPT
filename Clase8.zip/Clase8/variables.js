let nombre = "gachi";
const edad = 26;
signo = "Geminis";
console.log (`hola, mi nombre es ${nombre} y tengo ${edad} anios`);


// cambiar el valor de una variable 
nombre = "pachi";
// const edad = 26; no se puede cambiar xq es una constante
console.log (`hola, mi nombre es ${nombre} y tengo ${edad} anios soy del signo ${signo}`);
